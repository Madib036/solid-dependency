// Simple Express server that proxies an external joke API and serves a small static UI.
//
// Requires Node 18+ (uses global fetch).
const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static UI
app.use(express.static(path.join(__dirname, 'public')));

// Proxy endpoint: GET /api/joke
// Fetches a random joke from Official Joke API and returns it to the client.
// External API: https://official-joke-api.appspot.com/random_joke
app.get('/api/joke', async (req, res) => {
  try {
    const externalUrl = 'https://official-joke-api.appspot.com/random_joke';
    const response = await fetch(externalUrl, { method: 'GET' });
    if (!response.ok) {
      const text = await response.text();
      return res.status(502).json({ error: 'Bad response from external joke API', details: text });
    }
    const joke = await response.json();
    // Normalize response shape for the client
    res.json({
      id: joke.id,
      type: joke.type,
      setup: joke.setup,
      punchline: joke.punchline,
      source: 'official-joke-api'
    });
  } catch (err) {
    console.error('Error fetching joke:', err);
    res.status(500).json({ error: 'Failed to fetch joke', details: err.message });
  }
});

// Health check
app.get('/healthz', (req, res) => res.send('OK'));

// Start server
app.listen(PORT, () => {
  console.log(`Random joke generator running on http://localhost:${PORT}`);
});