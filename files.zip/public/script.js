const newJokeBtn = document.getElementById('newJoke');
const copyBtn = document.getElementById('copy');
const setupEl = document.getElementById('setup');
const punchlineEl = document.getElementById('punchline');
const metaEl = document.getElementById('meta');

async function fetchJoke() {
  setLoading(true);
  try {
    const resp = await fetch('/api/joke');
    if (!resp.ok) throw new Error('Failed to fetch joke');
    const data = await resp.json();
    showJoke(data);
  } catch (err) {
    setupEl.textContent = 'Sorry — could not load a joke.';
    punchlineEl.textContent = err.message || String(err);
    metaEl.textContent = '';
  } finally {
    setLoading(false);
  }
}

function showJoke(j) {
  setupEl.textContent = j.setup || '';
  punchlineEl.textContent = j.punchline || '';
  metaEl.textContent = `Type: ${j.type || 'unknown'} | Source: ${j.source || 'external'}`;
}

function setLoading(isLoading) {
  newJokeBtn.disabled = isLoading;
  copyBtn.disabled = isLoading || !punchlineEl.textContent;
  newJokeBtn.textContent = isLoading ? 'Loading…' : 'Get another joke';
}

newJokeBtn.addEventListener('click', fetchJoke);
copyBtn.addEventListener('click', async () => {
  const text = punchlineEl.textContent;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = 'Copied!';
    setTimeout(() => (copyBtn.textContent = 'Copy punchline'), 1500);
  } catch {
    copyBtn.textContent = 'Copy failed';
    setTimeout(() => (copyBtn.textContent = 'Copy punchline'), 1500);
  }
});

// Load first joke on page load
fetchJoke();