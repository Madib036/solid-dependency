# Random Joke Generator

A minimal random joke generator that proxies an external joke API and provides a small static UI.

- Backend: Express server (Node 18+; uses global `fetch`) that proxies the Official Joke API: https://official-joke-api.appspot.com/random_joke
- Frontend: Simple HTML/JS that requests `/api/joke` and displays the joke.

Prerequisites
- Node 18 or newer

Install & run
```bash
npm install
npm start
```

Then open http://localhost:3000

Endpoints
- GET /api/joke — returns a JSON object with a random joke:
  - { id, type, setup, punchline, source }

Notes & next steps
- You can swap the external API to any other joke provider (e.g., icanhazdadjoke). If using icanhazdadjoke from the server, add the required `Accept: application/json` header.
- Add caching, rate-limiting, or a favorites list to improve UX and reduce external API requests.
- For production, add proper logging, health checks, containerization, and an environment variable for the external API URL.